#ifndef AUXILIARES
#define AUXILIARES

#include "registro_dados.h"
#include "cabecalho.h"
#include <stdio.h>




int procurar_nome_estacao(char* nome, char** nomes,int tam);
int procurar_par(par *p, par** pares, int tam);
reg_dados* ler_dados(char* linha);
reg_dados **busca(char campos[][50], char valores[][50],int m, FILE *arquivo);

#endif